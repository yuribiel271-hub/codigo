package com.example.msc;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class PlaylistActivity extends AppCompatActivity {

    TextView nomePlaylist;

    Button botaoVoltar;
    Button botaoAdicionar;

    LinearLayout listaMusicas;

    String nomeDaPlaylist;

    String[] musicas = {
            "Música Teste 01",
            "Música Teste 02",
            "Música Teste 03",
            "Música Teste 04",
            "Música Teste 05"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_playlist);

        nomePlaylist = findViewById(R.id.nomePlaylist);

        botaoVoltar = findViewById(R.id.botaoVoltar);
        botaoAdicionar = findViewById(R.id.botaoAdicionar);

        listaMusicas = findViewById(R.id.listaMusicas);

        nomeDaPlaylist =
                getIntent().getStringExtra("nome_playlist");

        if (nomeDaPlaylist != null) {

            nomePlaylist.setText(nomeDaPlaylist);
        }

        mostrarMusicasDaPlaylist();

        botaoVoltar.setOnClickListener(v -> {

            finish();

        });

        botaoAdicionar.setOnClickListener(v -> {

            mostrarMusicasParaAdicionar();

        });
    }

    private void mostrarMusicasParaAdicionar() {

        listaMusicas.removeAllViews();

        TextView titulo = new TextView(this);

        titulo.setText("Escolha uma música:");
        titulo.setTextColor(0xFFFFFFFF);
        titulo.setTextSize(20);

        listaMusicas.addView(titulo);

        for (String musica : musicas) {

            Button botaoMusica = new Button(this);

            botaoMusica.setText("♪  " + musica);

            botaoMusica.setOnClickListener(v -> {

                adicionarMusica(musica);

            });

            listaMusicas.addView(botaoMusica);
        }
    }

    private void adicionarMusica(String musica) {

        SharedPreferences dados =
                getSharedPreferences(
                        "musicas_playlist",
                        MODE_PRIVATE
                );

        String musicasSalvas =
                dados.getString(nomeDaPlaylist, "");

        if (musicasSalvas.contains(musica)) {

            Toast.makeText(
                    this,
                    "Essa música já está na playlist.",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        if (musicasSalvas.isEmpty()) {

            musicasSalvas = musica;

        } else {

            musicasSalvas =
                    musicasSalvas + "|" + musica;
        }

        dados.edit()
                .putString(nomeDaPlaylist, musicasSalvas)
                .apply();

        Toast.makeText(
                this,
                "Música adicionada!",
                Toast.LENGTH_SHORT
        ).show();

        mostrarMusicasDaPlaylist();
    }

    private void mostrarMusicasDaPlaylist() {

        listaMusicas.removeAllViews();

        SharedPreferences dados =
                getSharedPreferences(
                        "musicas_playlist",
                        MODE_PRIVATE
                );

        String musicasSalvas =
                dados.getString(nomeDaPlaylist, "");

        if (musicasSalvas.isEmpty()) {

            TextView mensagem = new TextView(this);

            mensagem.setText(
                    "Essa playlist ainda não possui músicas."
            );

            mensagem.setTextColor(0xFFAAAAAA);
            mensagem.setTextSize(16);
            mensagem.setGravity(Gravity.CENTER);
            mensagem.setPadding(10, 30, 10, 30);

            listaMusicas.addView(mensagem);

            return;
        }

        String[] lista =
                musicasSalvas.split("\\|");

        for (String musica : lista) {

            TextView item = new TextView(this);

            item.setText("♪  " + musica);
            item.setTextColor(0xFFFFFFFF);
            item.setTextSize(18);
            item.setGravity(Gravity.CENTER_VERTICAL);

            LinearLayout.LayoutParams parametros =
                    new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            65
                    );

            parametros.setMargins(0, 5, 0, 5);

            item.setLayoutParams(parametros);

            item.setOnClickListener(v -> {

                Intent intent =
                        new Intent(
                                PlaylistActivity.this,
                                PlayerActivity.class
                        );

                intent.putExtra(
                        "nome_musica",
                        musica
                );

                startActivity(intent);
            });

            listaMusicas.addView(item);
        }
    }
}