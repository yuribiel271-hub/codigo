package com.example.msc;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class PerfilActivity extends AppCompatActivity {

    TextView nomeUsuario;
    TextView emailUsuario;

    Button botaoVoltar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_perfil);

        nomeUsuario = findViewById(R.id.nomeUsuario);
        emailUsuario = findViewById(R.id.emailUsuario);

        botaoVoltar = findViewById(R.id.botaoVoltar);

        SharedPreferences dados =
                getSharedPreferences(
                        "dados_usuario",
                        MODE_PRIVATE
                );

        String nome =
                dados.getString("nome", "");

        String email =
                dados.getString("email", "");

        nomeUsuario.setText(nome);
        emailUsuario.setText(email);

        botaoVoltar.setOnClickListener(v -> {

            finish();

        });
    }
}