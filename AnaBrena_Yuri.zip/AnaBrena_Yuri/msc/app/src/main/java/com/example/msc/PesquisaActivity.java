package com.example.msc;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class PesquisaActivity extends AppCompatActivity {

    EditText campoPesquisa;
    Button botaoBuscar;

    LinearLayout listaResultados;

    String[] musicas = {
            "Música Teste 01",
            "Música Teste 02",
            "Música Teste 03",
            "Música Teste 04",
            "Música Teste 05"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_pesquisa);

        campoPesquisa = findViewById(R.id.campoPesquisa);
        botaoBuscar = findViewById(R.id.botaoBuscar);

        listaResultados = findViewById(R.id.listaResultados);

        botaoBuscar.setOnClickListener(v -> {

            pesquisarMusica();

        });

        mostrarTodasAsMusicas();

        Button botaoInicio = findViewById(R.id.botaoInicio);
        Button botaoPesquisa = findViewById(R.id.botaoPesquisa);
        Button botaoBiblioteca = findViewById(R.id.botaoBiblioteca);

        botaoInicio.setOnClickListener(v -> {

            Intent intent =
                    new Intent(PesquisaActivity.this, MenuActivity.class);

            startActivity(intent);

            finish();
        });

        botaoPesquisa.setOnClickListener(v -> {

            // Já estamos na pesquisa.

        });

        botaoBiblioteca.setOnClickListener(v -> {

            Intent intent =
                    new Intent(
                            PesquisaActivity.this,
                            BibliotecaActivity.class
                    );

            startActivity(intent);

            finish();
        });
    }

    private void mostrarTodasAsMusicas() {

        listaResultados.removeAllViews();

        for (String musica : musicas) {

            adicionarMusica(musica);
        }
    }

    private void pesquisarMusica() {

        String pesquisa =
                campoPesquisa.getText().toString().toLowerCase();

        listaResultados.removeAllViews();

        for (String musica : musicas) {

            if (musica.toLowerCase().contains(pesquisa)) {

                adicionarMusica(musica);
            }
        }
    }

    private void adicionarMusica(String nomeMusica) {

        TextView musica = new TextView(this);

        musica.setText("♪  " + nomeMusica);
        musica.setTextColor(0xFFFFFFFF);
        musica.setTextSize(18);
        musica.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout.LayoutParams parametros =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        65
                );

        parametros.setMargins(0, 5, 0, 5);

        musica.setLayoutParams(parametros);

        musica.setOnClickListener(v -> {

            Intent intent =
                    new Intent(
                            PesquisaActivity.this,
                            PlayerActivity.class
                    );

            intent.putExtra("nome_musica", nomeMusica);

            startActivity(intent);
        });

        listaResultados.addView(musica);
    }
}