package com.example.msc;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    EditText email;
    EditText senha;

    Button botaoEntrar;
    Button botaoCadastro;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_login);

        email = findViewById(R.id.email);
        senha = findViewById(R.id.senha);

        botaoEntrar = findViewById(R.id.botaoEntrar);
        botaoCadastro = findViewById(R.id.botaoCadastro);

        botaoCadastro.setOnClickListener(v -> {

            Intent intent =
                    new Intent(LoginActivity.this, CadastroActivity.class);

            startActivity(intent);
        });

        botaoEntrar.setOnClickListener(v -> {

            String emailDigitado =
                    email.getText().toString();

            String senhaDigitada =
                    senha.getText().toString();

            SharedPreferences dados =
                    getSharedPreferences("dados_usuario", MODE_PRIVATE);

            String emailSalvo =
                    dados.getString("email", "");

            String senhaSalva =
                    dados.getString("senha", "");

            if (emailDigitado.equals(emailSalvo) &&
                    senhaDigitada.equals(senhaSalva)) {

                Toast.makeText(this,
                        "Login realizado!",
                        Toast.LENGTH_SHORT).show();

                Intent intent =
                        new Intent(LoginActivity.this, MenuActivity.class);

                startActivity(intent);

                finish();

            } else {

                Toast.makeText(this,
                        "E-mail ou senha incorretos",
                        Toast.LENGTH_SHORT).show();
            }
        });
    }
}