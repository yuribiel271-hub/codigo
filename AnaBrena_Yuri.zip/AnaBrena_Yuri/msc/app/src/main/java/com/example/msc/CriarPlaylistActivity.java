package com.example.msc;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class CriarPlaylistActivity extends AppCompatActivity {

    EditText nomePlaylist;

    Button botaoCriar;
    Button botaoCancelar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_criar_playlist);

        nomePlaylist = findViewById(R.id.nomePlaylist);

        botaoCriar = findViewById(R.id.botaoCriar);
        botaoCancelar = findViewById(R.id.botaoCancelar);

        botaoCriar.setOnClickListener(v -> {

            String nome =
                    nomePlaylist.getText().toString().trim();

            if (nome.isEmpty()) {

                Toast.makeText(
                        this,
                        "Digite um nome para a playlist",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            SharedPreferences dados =
                    getSharedPreferences(
                            "playlists",
                            MODE_PRIVATE
                    );

            String playlists =
                    dados.getString("lista", "");

            if (!playlists.isEmpty()) {

                String[] lista =
                        playlists.split("\\|");

                for (String playlist : lista) {

                    if (playlist.equalsIgnoreCase(nome)) {

                        Toast.makeText(
                                this,
                                "Essa playlist já existe.",
                                Toast.LENGTH_SHORT
                        ).show();

                        return;
                    }
                }
            }

            if (playlists.isEmpty()) {

                playlists = nome;

            } else {

                playlists =
                        playlists + "|" + nome;
            }

            dados.edit()
                    .putString("lista", playlists)
                    .apply();

            Toast.makeText(
                    this,
                    "Playlist criada!",
                    Toast.LENGTH_SHORT
            ).show();

            Intent intent =
                    new Intent(
                            CriarPlaylistActivity.this,
                            BibliotecaActivity.class
                    );

            intent.setFlags(
                    Intent.FLAG_ACTIVITY_CLEAR_TOP
            );

            startActivity(intent);

            finish();
        });

        botaoCancelar.setOnClickListener(v -> {

            finish();

        });
    }
}