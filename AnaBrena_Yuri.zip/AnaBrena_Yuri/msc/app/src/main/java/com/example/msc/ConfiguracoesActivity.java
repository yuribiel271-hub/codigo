package com.example.msc;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Switch;

import androidx.appcompat.app.AppCompatActivity;

public class ConfiguracoesActivity extends AppCompatActivity {

    Button botaoPerfil;
    Button botaoSair;

    Switch switchSom;
    Switch switchMusica;

    SharedPreferences configuracoes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_configuracoes);

        botaoPerfil = findViewById(R.id.botaoPerfil);
        botaoSair = findViewById(R.id.botaoSair);

        switchSom = findViewById(R.id.switchSom);
        switchMusica = findViewById(R.id.switchMusica);

        configuracoes =
                getSharedPreferences(
                        "configuracoes",
                        MODE_PRIVATE
                );

        boolean somAtivo =
                configuracoes.getBoolean("som", true);

        boolean musicaAtiva =
                configuracoes.getBoolean("musica", true);

        switchSom.setChecked(somAtivo);
        switchMusica.setChecked(musicaAtiva);

        botaoPerfil.setOnClickListener(v -> {

            Intent intent =
                    new Intent(
                            ConfiguracoesActivity.this,
                            PerfilActivity.class
                    );

            startActivity(intent);
        });

        switchSom.setOnCheckedChangeListener(
                (buttonView, isChecked) -> {

                    configuracoes.edit()
                            .putBoolean("som", isChecked)
                            .apply();
                }
        );

        switchMusica.setOnCheckedChangeListener(
                (buttonView, isChecked) -> {

                    configuracoes.edit()
                            .putBoolean("musica", isChecked)
                            .apply();
                }
        );

        botaoSair.setOnClickListener(v -> {

            SharedPreferences dados =
                    getSharedPreferences(
                            "dados_usuario",
                            MODE_PRIVATE
                    );

            dados.edit().clear().apply();

            Intent intent =
                    new Intent(
                            ConfiguracoesActivity.this,
                            LoginActivity.class
                    );

            intent.setFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK |
                            Intent.FLAG_ACTIVITY_CLEAR_TASK
            );

            startActivity(intent);

            finish();
        });
    }
}