package com.example.msc;

import android.os.Bundle;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class PlayerActivity extends AppCompatActivity {

    TextView nomeMusica;

    Button botaoVoltar;
    Button botaoAnterior;
    Button botaoPlay;
    Button botaoProxima;

    SeekBar barraMusica;

    String[] musicas = {
            "Música Teste 01",
            "Música Teste 02",
            "Música Teste 03",
            "Música Teste 04",
            "Música Teste 05"
    };

    int musicaAtual = 0;

    boolean musicaTocando = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_player);

        nomeMusica = findViewById(R.id.nomeMusica);

        botaoVoltar = findViewById(R.id.botaoVoltar);
        botaoAnterior = findViewById(R.id.botaoAnterior);
        botaoPlay = findViewById(R.id.botaoPlay);
        botaoProxima = findViewById(R.id.botaoProxima);

        barraMusica = findViewById(R.id.barraMusica);

        String musicaRecebida =
                getIntent().getStringExtra("nome_musica");

        if (musicaRecebida != null) {

            for (int i = 0; i < musicas.length; i++) {

                if (musicas[i].equals(musicaRecebida)) {

                    musicaAtual = i;

                    break;
                }
            }
        }

        mostrarMusica();

        botaoVoltar.setOnClickListener(v -> {

            finish();

        });

        botaoPlay.setOnClickListener(v -> {

            if (musicaTocando) {

                musicaTocando = false;

                botaoPlay.setText("▶");

            } else {

                musicaTocando = true;

                botaoPlay.setText("⏸");
            }
        });

        botaoAnterior.setOnClickListener(v -> {

            musicaAnterior();

        });

        botaoProxima.setOnClickListener(v -> {

            musicaProxima();

        });
    }

    private void mostrarMusica() {

        nomeMusica.setText(
                musicas[musicaAtual]
        );

        barraMusica.setProgress(0);

        musicaTocando = false;

        botaoPlay.setText("▶");
    }

    private void musicaAnterior() {

        if (musicaAtual > 0) {

            musicaAtual--;

        } else {

            musicaAtual = musicas.length - 1;
        }

        mostrarMusica();
    }

    private void musicaProxima() {

        if (musicaAtual < musicas.length - 1) {

            musicaAtual++;

        } else {

            musicaAtual = 0;
        }

        mostrarMusica();
    }
}