package com.example.msc;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class CadastroActivity extends AppCompatActivity {

    EditText nome;
    EditText email;
    EditText senha;
    EditText confirmarSenha;

    Button botaoCadastrar;
    Button botaoVoltarLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_cadastro);

        nome = findViewById(R.id.nome);
        email = findViewById(R.id.email);
        senha = findViewById(R.id.senha);
        confirmarSenha = findViewById(R.id.confirmarSenha);

        botaoCadastrar = findViewById(R.id.botaoCadastrar);
        botaoVoltarLogin = findViewById(R.id.botaoVoltarLogin);

        botaoCadastrar.setOnClickListener(v -> {

            String nomeUsuario = nome.getText().toString();
            String emailUsuario = email.getText().toString();
            String senhaUsuario = senha.getText().toString();
            String confirmar = confirmarSenha.getText().toString();

            if (nomeUsuario.isEmpty() ||
                    emailUsuario.isEmpty() ||
                    senhaUsuario.isEmpty() ||
                    confirmar.isEmpty()) {

                Toast.makeText(this,
                        "Preencha todos os campos",
                        Toast.LENGTH_SHORT).show();

                return;
            }

            if (!senhaUsuario.equals(confirmar)) {

                Toast.makeText(this,
                        "As senhas não são iguais",
                        Toast.LENGTH_SHORT).show();

                return;
            }

            SharedPreferences dados =
                    getSharedPreferences("dados_usuario", MODE_PRIVATE);

            SharedPreferences.Editor editor = dados.edit();

            editor.putString("nome", nomeUsuario);
            editor.putString("email", emailUsuario);
            editor.putString("senha", senhaUsuario);

            editor.apply();

            Toast.makeText(this,
                    "Conta criada com sucesso!",
                    Toast.LENGTH_SHORT).show();

            Intent intent =
                    new Intent(CadastroActivity.this, LoginActivity.class);

            startActivity(intent);

            finish();
        });

        botaoVoltarLogin.setOnClickListener(v -> {

            Intent intent =
                    new Intent(CadastroActivity.this, LoginActivity.class);

            startActivity(intent);

            finish();
        });
    }
}