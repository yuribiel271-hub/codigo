package com.example.msc;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MenuActivity extends AppCompatActivity {

    Button botaoConfiguracoes;
    Button botaoPesquisar;

    Button botaoPesquisa;
    Button botaoInicio;
    Button botaoBiblioteca;

    String[] musicas = {
            "Música Teste 01",
            "Música Teste 02"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_menu);

        botaoConfiguracoes =
                findViewById(R.id.botaoConfiguracoes);

        botaoPesquisar =
                findViewById(R.id.botaoPesquisar);

        botaoPesquisa =
                findViewById(R.id.botaoPesquisa);

        botaoInicio =
                findViewById(R.id.botaoInicio);

        botaoBiblioteca =
                findViewById(R.id.botaoBiblioteca);

        botaoConfiguracoes.setOnClickListener(v -> {

            abrirConfiguracoes();

        });

        botaoPesquisar.setOnClickListener(v -> {

            abrirPesquisa();

        });

        botaoPesquisa.setOnClickListener(v -> {

            abrirPesquisa();

        });

        botaoInicio.setOnClickListener(v -> {

            // Já estamos no início.

        });

        botaoBiblioteca.setOnClickListener(v -> {

            abrirBiblioteca();

        });

        configurarMusicas();
    }

    private void configurarMusicas() {

        TextView musica1 = encontrarMusica("Música 1");
        TextView musica2 = encontrarMusica("Música 2");

        if (musica1 != null) {

            musica1.setOnClickListener(v -> {

                abrirPlayer("Música Teste 01");

            });
        }

        if (musica2 != null) {

            musica2.setOnClickListener(v -> {

                abrirPlayer("Música Teste 02");

            });
        }
    }

    private TextView encontrarMusica(String nome) {

        View view = procurarView(
                ((android.view.ViewGroup) findViewById(android.R.id.content)),
                nome
        );

        if (view instanceof TextView) {

            return (TextView) view;
        }

        return null;
    }

    private View procurarView(
            android.view.ViewGroup grupo,
            String nome) {

        for (int i = 0; i < grupo.getChildCount(); i++) {

            View view = grupo.getChildAt(i);

            if (view instanceof TextView) {

                TextView texto = (TextView) view;

                if (texto.getText().toString().equals(nome)) {

                    return view;
                }
            }

            if (view instanceof android.view.ViewGroup) {

                View encontrado = procurarView(
                        (android.view.ViewGroup) view,
                        nome
                );

                if (encontrado != null) {

                    return encontrado;
                }
            }
        }

        return null;
    }

    private void abrirPlayer(String musica) {

        Intent intent =
                new Intent(
                        MenuActivity.this,
                        PlayerActivity.class
                );

        intent.putExtra("nome_musica", musica);

        startActivity(intent);
    }

    private void abrirConfiguracoes() {

        Intent intent =
                new Intent(
                        MenuActivity.this,
                        ConfiguracoesActivity.class
                );

        startActivity(intent);
    }

    private void abrirPesquisa() {

        Intent intent =
                new Intent(
                        MenuActivity.this,
                        PesquisaActivity.class
                );

        startActivity(intent);
    }

    private void abrirBiblioteca() {

        Intent intent =
                new Intent(
                        MenuActivity.this,
                        BibliotecaActivity.class
                );

        startActivity(intent);
    }
}