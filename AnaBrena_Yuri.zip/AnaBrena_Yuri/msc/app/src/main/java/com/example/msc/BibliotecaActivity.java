package com.example.msc;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class BibliotecaActivity extends AppCompatActivity {

    Button botaoCriarPlaylist;

    Button botaoInicio;
    Button botaoPesquisa;
    Button botaoBiblioteca;

    LinearLayout listaPlaylists;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_biblioteca);

        botaoCriarPlaylist =
                findViewById(R.id.botaoCriarPlaylist);

        botaoInicio =
                findViewById(R.id.botaoInicio);

        botaoPesquisa =
                findViewById(R.id.botaoPesquisa);

        botaoBiblioteca =
                findViewById(R.id.botaoBiblioteca);

        listaPlaylists =
                findViewById(R.id.listaPlaylists);

        mostrarPlaylists();

        botaoCriarPlaylist.setOnClickListener(v -> {

            Intent intent =
                    new Intent(
                            BibliotecaActivity.this,
                            CriarPlaylistActivity.class
                    );

            startActivity(intent);
        });

        botaoInicio.setOnClickListener(v -> {

            Intent intent =
                    new Intent(
                            BibliotecaActivity.this,
                            MenuActivity.class
                    );

            startActivity(intent);

            finish();
        });

        botaoPesquisa.setOnClickListener(v -> {

            Intent intent =
                    new Intent(
                            BibliotecaActivity.this,
                            PesquisaActivity.class
                    );

            startActivity(intent);

            finish();
        });

        botaoBiblioteca.setOnClickListener(v -> {

            mostrarPlaylists();

        });
    }

    @Override
    protected void onResume() {
        super.onResume();

        mostrarPlaylists();
    }

    private void mostrarPlaylists() {

        listaPlaylists.removeAllViews();

        SharedPreferences dados =
                getSharedPreferences(
                        "playlists",
                        MODE_PRIVATE
                );

        String playlists =
                dados.getString("lista", "");

        if (playlists.isEmpty()) {

            TextView mensagem = new TextView(this);

            mensagem.setText(
                    "Você ainda não criou nenhuma playlist."
            );

            mensagem.setTextColor(0xFFAAAAAA);
            mensagem.setTextSize(16);
            mensagem.setGravity(Gravity.CENTER);
            mensagem.setPadding(10, 30, 10, 30);

            listaPlaylists.addView(mensagem);

            return;
        }

        String[] nomes =
                playlists.split("\\|");

        for (String nome : nomes) {

            TextView playlist =
                    new TextView(this);

            playlist.setText(
                    "🎵  " + nome
            );

            playlist.setTextColor(0xFFFFFFFF);
            playlist.setTextSize(18);
            playlist.setGravity(Gravity.CENTER_VERTICAL);

            LinearLayout.LayoutParams parametros =
                    new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            70
                    );

            parametros.setMargins(0, 5, 0, 5);

            playlist.setLayoutParams(parametros);

            playlist.setOnClickListener(v -> {

                Intent intent =
                        new Intent(
                                BibliotecaActivity.this,
                                PlaylistActivity.class
                        );

                intent.putExtra(
                        "nome_playlist",
                        nome
                );

                startActivity(intent);
            });

            listaPlaylists.addView(playlist);
        }
    }
}